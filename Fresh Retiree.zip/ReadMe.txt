Please don't spam the dialogue, as sometimes the game will stop working

thats it, hope you enjoy.